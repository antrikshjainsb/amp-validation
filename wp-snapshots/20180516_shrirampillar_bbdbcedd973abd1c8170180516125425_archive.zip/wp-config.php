<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'shriram-pillar');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'z~/}3SL;Y3eK Jq :=?vpVk*7:cvf1jLisjd3,vQ-=8N8/~Iw~#eF>{Au`w>r/!S');
define('SECURE_AUTH_KEY',  'k(`W5$tnr#CK)?hpd+.^d6&H|}zLzv@VsOsD.vf(n&x4,U$)`Pea{t 31*|/4_eZ');
define('LOGGED_IN_KEY',    'pU%d?`5]1YQm jtV4W)O!M`UgWDHr.*y;]y6)#JF(IP@VRR@PFqEy{9v*taFyME-');
define('NONCE_KEY',        'L[F;~,4,TrRI.)AL/lN?_yEncXW,EK.s0-PDf-s1?yh6}Rs@wy;+I8@/kN(=(@k.');
define('AUTH_SALT',        ';|wfeDaovGsN3VE%Bu2rI1T|]M:bPtL$&_yJO*%.kASQGMvPFn{dN2[KO6q)Ghl>');
define('SECURE_AUTH_SALT', 'h-7bPfonbNIqsp<z$I6Hc@.6$2F~>/]PtxHB~VU[PKB.MvXjmrpC3gp}SKKW~sw<');
define('LOGGED_IN_SALT',   'o8Rs/-O+NX|udkJ];$W2tP:%QLU](C4BE)g4,W`^C-]7?k/bQv$,4zm[L.M2iF@j');
define('NONCE_SALT',       'pk^N@v|y/WnQidG)N</pi^ABF^Y$J=55KC?sQ-lI4y,k{xX[t=N+HD(sZem^!(fD');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
